
library(glmnet)
library(pROC)
library(ggsci)

riskFile="GSE57338C&P.txt"    
rt=read.table(riskFile, header=T, sep="\t", check.names=F,row.names = 1)
rt = as.data.frame(t(rt))

sample = read.delim("sample.txt",header = F)

rt1 = merge(rt,sample,by.x = 0, by.y = 1)
row.names(rt1) = rt1$Row.names
rt1$Row.names = NULL

gene = read.delim("hub.txt",header = F)
gene = gene$V1

rt1 = rt1[,c(gene,"V2")]
colnames(rt1)
colnames(rt1)[3] = "Type"
rt = rt1
colnames(rt)
rt = rt[c("Type",gene)]
y=rt[,"Type"]
aucText=c()
k=0
for(x in colnames(rt)[2:ncol(rt)]){
  k=k+1
  roc1=roc(y, as.numeric(rt[,x]))  
  if(k==1){
    pdf(file="ROC.pdf", width=4.5, height=4.7)
    plot(roc1, lwd=4,print.auc=F, col=cols[k], legacy.axes=T, main="")
    aucText=c(aucText, paste0(x,", AUC=",sprintf("%.3f",roc1$auc[1])))
  }else{
    plot(roc1,lwd=4, print.auc=F, col=cols[k], legacy.axes=T, main="", add=TRUE)
    aucText=c(aucText, paste0(x,", AUC=",sprintf("%.3f",roc1$auc[1])))
  }
}
legend("bottomright", aucText, lwd=4, bty="n", col=cols, cex=0.7)
dev.off()


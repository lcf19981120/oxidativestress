


dir.create('results')
gse.dat<-read.delim('GSE57338_GPL11532_1_10_0_XML.matrix.txt',check.names = F,header = T)

gse.dat[1:4,1:4]
gse.dat$Tag = sapply(strsplit(gse.dat$Tag,"//"),"[",2)
gse.dat$Tag2 <- gsub("\\s+", "", gse.dat$Tag)
gse.dat$Tag2
gse.dat$Tag = gse.dat$Tag2  
gse.dat$Tag2 =NULL
gse.dat[1:4,1:4]
##########################################################################


gse.dat=gse.dat[-grep('/',gse.dat$Tag),]
gse.dat=aggregate(.~Tag,gse.dat,mean)
rownames(gse.dat)=gse.dat$Tag
gse.dat=gse.dat[,-1]

range(gse.dat) 
#gse.dat=log2(gse.dat+1)
max(gse.dat)
min(gse.dat)
#write.table(gse.cli,'results/GSE31210.cli.txt',sep='\t',quote = F,row.names = F)
out = cbind(id = row.names(gse.dat),gse.dat)
write.table(out,'results/GSE57338.txt',sep='\t',quote = F,row.names = F)


ann = read.delim("clinical.txt",sep='\t',check.names = F)
colnames(ann)
table(ann$`disease status`)
ann = ann[,c("Accession","disease status")]
colnames(ann)
table(ann$`disease status`)
colnames(ann)[2] = "Source"
HF = subset(ann,Source %in% c("idiopathic dilated CMP","ischemic"))
HFid = HF$Accession

table(ann$Source)
Control = subset(ann,Source %in% c("non-failing"))
Controlid = Control$Accession

HF1 = gse.dat[,HFid]
Control1 = gse.dat[,Controlid]

identical(row.names(HF1),row.names(Control1))
GSE57338out = cbind(Control1,HF1)

GSE57338 = cbind(id = row.names(GSE57338out),GSE57338out)
write.table(GSE57338,'results/GSE57338C&P.txt',sep='\t',quote = F,row.names = F)





library(Seurat)
library(SingleR)
library(dplyr)
library(tidyverse)
library(patchwork)
library(ggplot2)
library(harmony)
library(devtools)
library(tidydr)
library(ggunchull)
library(paletteer)
library(ggsci)
library(data.table)
library(data.table)
library(Seurat)
library(data.table)
library(Seurat)
gc()

load("../GSE183852_DCM_Integrated.Robj")
table(RefMerge$orig.ident)
length(unique(RefMerge$orig.ident))
scRNA = RefMerge
length(unique(scRNA@meta.data$orig.ident))
#QC 
scRNA <- subset(scRNA, 
                subset = nFeature_RNA > 200 & 
                  nFeature_RNA < 7000 &
                  percent.MT < 20&
                  percent.HB < 3&
                  nCount_RNA < 100000)
length(scRNA@active.ident)

# ann
scRNA = readRDS("scRNAunann.rds")

##cluster_umap
DimPlot(scRNA, 
        reduction = "tsne",
        group.by ="seurat_clusters",label = T,
        label.size = 5#,label.color = "black"
)
ggsave(filename = "cluster_tsne.pdf",height = 5.1,width = 6)

##cluster_umap
DimPlot(scRNA, 
        reduction = "umap",
        group.by ="seurat_clusters",label = T,
        label.size = 5#,label.color = "black"
)
ggsave(filename = "cluster_umap.pdf",height = 5.1,width = 6)

habermann_imm <- c("CD3E","CD8A","CCL5","IL7R","NKG7","KLRD1","KLRB1","NCR1","GZMB", ##T/NK 
                   "LEPR",#EC 
                   "KCNJ8",#PC Pericytes
                   # "C1QC","",# Myeloid
                   "PLIN1",# Adipocytes
                   "MS4A1","CD79A","CD19",# B cells
                   "KIT","GATA2","CPA3", #Mast
                   "HAS1", ##Epicardium
                   "NRXN1", #Neuron
                   "CCL21",# LEC
                   "VWF","PECAM1",# Endo
                   "PDGFRA","LUM", #Fibroblasts
                   "MYLK","ACTA2","PDGFRB","MYH11",##Smooth muscle
                   "RYR2", #Cardiomyocytes cm
                   "S100A12","S100A9",#Monocytes
                   "CD68","C1QA","MARCO")#Macrophages

### 
celltype <- c('Fibroblasts',
              'Cardiomyocytes',
              'Endothelium',
              'Pericytes',
              'Fibroblasts',
              'Cardiomyocytes',
              'Endothelium',
              'Fibroblasts',
              'Macrophages',
              'Endothelium',
              'Macrophages',
              'Pericytes',
              'Macrophages',
              "NK/T",
              "SMC",
              'Endothelium',
              'Endothelium',
              "LEC",
              "Neuron",
              'Macrophages',
              "Epicardium",
              "Mast",
              "Adipocytes",
              'Endothelium',
              'Macrophages',
              'Fibroblasts',
              "LEC",
              "B")


Idents(scRNA) <- scRNA@meta.data$seurat_clusters
names(celltype) <- levels(scRNA)
scRNA<- RenameIdents(scRNA, celltype)
scRNA@meta.data$celltype <- Idents(scRNA)
Idents(scRNA)=scRNA@meta.data$celltype
DimPlot(scRNA, group.by="celltype", label=T, label.size=5, reduction='tsne',pt.size = 1)
DimPlot(scRNA, group.by="celltype", label=T, label.size=5, reduction='umap',pt.size = 1)

##### ע�����
colors=c("#5E4FA2","#3288BD","#ABDDA4", "#E6F598", "#FEE08B","#FDAE61")
DimPlot(scRNA, group.by="celltype", label=T, #label.size=3, 
        reduction='tsne',pt.size = 0.4,cols = colors)
cli=cli[,c("Tissue","celltype")]
A <- prop.table(table(cli$celltype, cli$Tissue), margin = 2)
A <- as.data.frame(A)
colnames(A) <- c("celltype", "Tissue", "Freq")
cluster_cols <- colors
unique(scRNA$Tissue)
A$Tissue=factor(A$Tissue,levels =c("NC","AD"))
ggplot(A,aes(x = Tissue,y =Freq,
             group=celltype))+
  stat_summary(geom = 'line',fun='mean',cex=1,col='white')+
  geom_area(data = A,aes(fill=celltype))+
  scale_fill_manual(values=cluster_cols)+
  ggtitle("Cell percentage")+
  labs(x=NULL,y=NULL)+
  
  geom_vline(aes(xintercept ="NC"),
             linetype="dashed", size=1.2, colour="white")+
  geom_vline(aes(xintercept ="AD"),
             linetype="dashed", size=1.2, colour="white")
ggsave("4.cell_bargroup.pdf",height = 4,width = 5)


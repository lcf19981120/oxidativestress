

library(ggpubr)          
library(limma)
library(ggsci)
expfile="GSE57338C&P.txt"         
hub="hub.txt"                   
sample="sample.txt"               
Ccol="#008280FF"                    
Pcol="#BB0021FF"                          
afmethod="t.test"       
df=c(3:ncol(rt1))

for (i in df) {

outFile=paste0(af[i],"_","boxplotdiff.pdf")             
rt=as.data.frame(rt1[,c(1,2,i)])
x=colnames(rt)[2]
y=colnames(rt)[3]
colnames(rt)=c("id","Type","Expression")


group=levels(factor(rt$Type))
rt$Type=factor(rt$Type, levels=group)
rt$Expression=as.numeric(rt$Expression)

comp=combn(group,2)
my_comparisons=list()
for(i in 1:ncol(comp)){my_comparisons[[i]]<-comp[,i]}


boxplot=ggboxplot(rt, x="Type", y="Expression", fill="Type",
		          xlab=x,     
		          ylab=y,
		          legend.title=x,
		          palette = c(Ccol,Pcol),   
		          #add = "jitter"
		          )+ 
	    stat_compare_means(comparisons = my_comparisons,method=afmethod,p.adjust.method = "bonferroni")


pdf(file=outFile,width=3.5,height=4.5)
print(boxplot)
dev.off()

}



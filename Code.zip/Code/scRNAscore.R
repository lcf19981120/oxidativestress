

library(Seurat)
library(AUCell) 
gc()


scRNA = readRDS("../1.scRNA/scRNAann.rds")
cells_rankings <- AUCell_buildRankings(scRNA@assays$RNA@data,  nCores=1, plotStats=TRUE) 
cells_AUC <- AUCell_calcAUC(geneset, cells_rankings,nCores =1, aucMaxRank=nrow(cells_rankings)*0.1)
aucs <- as.numeric(getAUC(cells_AUC)['Oxidative Stress', ])
scRNA=AddModuleScore(scRNA,features = geneset,name = 'Add')

normalize=function(x){
  return((x-min(x))/(max(x)-min(x)))}

score=apply(score, 2, normalize)
score=as.data.frame(score)
score$Scoring=rowSums(score)
colnames(scRNA@meta.data)
Idents(scRNA) = scRNA@meta.data$celltype
bb = DotPlot(scRNA,features = colnames(score),scale = T) + RotatedAxis() +
  theme(axis.text.x = element_text(angle = 45, face="italic", hjust=1), axis.text.y = element_text(face="bold")) + 
  scale_colour_gradientn(colours = pal)+ theme(legend.position="right")  + labs(title = "Oxidative Stress activity", y = "Celltype", x="") #����

ggsave('scoreDotPlot2.pdf',bb,height = 6.5,width = 6.5)
ss = VlnPlot(scRNA,features = colnames(score),split.by = 'celltype',pt.size = 0,cols = cols)
ggsave('scoreVlnPlot.pdf',ss,height = 7,width = 12)

##### umap
df<- data.frame(sc2@meta.data, sc2@reductions$umap@cell.embeddings)
colnames(df)
cols=brewer.pal(n=11,name="Spectral")
ggplot(df, aes(UMAP_1, UMAP_2))  +
  geom_point(aes(colour  = Scoring),size=0.2) +
  viridis::scale_color_viridis(option="D")+#A-F
  ggrepel::geom_label_repel(aes(label =celltype),
                            data = class_avg,
                            size = 2,
                            label.size = 2,
                            segment.color = NA
  ) + 
  labs(title = "Oxidative Stress activity") 

saveRDS(scRNA,file = "scRNAscore.rds")


library(cowplot)
library(ggplot2)
scRNA@assays$SCT@scale.data
exp<-GetAssayData(scRNA,slot="scale.data",assay="SCT") 
y <- scRNA@meta.data[colnames(exp),"Scoring"]
rownames <- rownames(exp)
exp1=exp[rownames,]
cor<-do.call(rbind,lapply(rownames, function(x){
  dd<- cor.test(as.numeric(exp1[x,]),y,type="spearman")
  data.frame(gene=x,
             cor=dd$estimate,
             p.value=dd$p.value)
}))
save(cor,file = "cor.rdata")

scRNAvol = readRDS("scRNAscore.rds")
Idents(scRNAvol)="Scoring_group"
table(scRNAvol$Scoring_group)
scRNAvol.markers <- FindMarkers(scRNAvol,
                                ident.1 = "high",
                                ident.2 = "low",
                                  logfc.threshold = 0.25,
                                   min.pct = 0.25
)

scRNAvol.markers$difference <- scRNAvol.markers$pct.1 - scRNAvol.markers$pct.2
scRNAvol.markers_sig <- scRNAvol.markers[which(scRNAvol.markers$p_val_adj<0.05 & abs(scRNAvol.markers$avg_log2FC) >0.25),]




rt = read.delim("GSE57338.txt",check.names = F,row.names = 1,header = T)
library(genefilter)
library(GSVA)
library(Biobase)
library(edgeR)

# gsva
gsva_matrix<- gsva(as.matrix(rt), gene_set,
                   method='ssgsea',kcdf='Gaussian',abs.ranking=TRUE)


gsva_matrix=as.data.frame(gsva_matrix)

sample = read.delim("sample.txt")
colnames(sample)
sample = sample[,c("Accession","group")]

rt = as.data.frame(t(gsva_matrix))
identical(sample$Accession,row.names(rt))
rt = cbind(rt,sample)
#rt$group=group_list
rt$Accession = NULL

library(ggpubr)

library(tidyverse)
colnames(rt)

P1 = ggboxplot(rt,x = "group",
               y = "OS",
               color = "black",
               fill = "group",
               xlab = "group",
               ylab = "OS", palette=c("#008280FF","#BB0021FF")
)+stat_compare_means()
ggsave('ScoreBoxplot.pdf',P1,height = 4.5,width = 3.5)
